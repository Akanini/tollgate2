package com.apps.tollgate2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tollgate2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
