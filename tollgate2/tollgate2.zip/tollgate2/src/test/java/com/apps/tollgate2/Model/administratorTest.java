package com.apps.tollgate2.Model;

import static org.junit.jupiter.api.Assertions.*;

class administratorTest {

}